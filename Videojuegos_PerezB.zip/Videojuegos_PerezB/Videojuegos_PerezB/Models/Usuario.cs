﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Videojuegos_PerezB.Models
{
    public class Usuario
    {
        [Key]
        public int IdUsuario { get; set; }
        [Required(ErrorMessage = "Login requerido")]
        public String Login { get; set; }
        [Required(ErrorMessage = "Contraseña requerida")]
        public String Password { get; set; }

        public Usuario()
        {
            UsuarioGrupo = new HashSet<UsuarioGrupo>();
        }

        public virtual ICollection<UsuarioGrupo> UsuarioGrupo { get; set; }
    }
}