﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Videojuegos_PerezB.Models;

namespace Videojuegos_PerezB.InfraLayer.Security
{
    public class CustomerFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            Usuario u = null;

            if (filterContext.HttpContext.Session["PERSONA"] is Usuario)
                u = filterContext.HttpContext.Session["PERSONA"] as Usuario;

            if (u == null || !u.UsuarioGrupo.Any(g => g.Grupo.Nombre == "customer"))
            {
                filterContext.Result = new ViewResult()
                {
                    ViewName = "AuthErr"
                };
            }
        }
        
    }
}