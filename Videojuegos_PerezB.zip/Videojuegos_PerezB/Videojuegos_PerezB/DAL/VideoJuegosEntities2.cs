﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using Videojuegos_PerezB.Models;

namespace Videojuegos_PerezB.DAL
{
    public class VideoJuegosEntities2 : DbContext
    {
        public VideoJuegosEntities2()
            : base("name=Usuarios")
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Usuario>().ToTable("Usuarios");
            modelBuilder.Entity<Grupo>().ToTable("Grupos");
            modelBuilder.Entity<UsuarioGrupo>().ToTable("UsuariosGrupos");
            base.OnModelCreating(modelBuilder);
        }

        public virtual DbSet<Usuario> Usuario { get; set; }
        public virtual DbSet<Grupo> Grupo { get; set; }
        public virtual DbSet<UsuarioGrupo> UsuarioGrupo { get; set; }
    }
}