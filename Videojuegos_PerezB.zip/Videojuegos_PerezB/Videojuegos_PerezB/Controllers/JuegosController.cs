﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Videojuegos_PerezB.Models;
using PagedList;
using System.Net;
using System.Data.Entity;
using Videojuegos_PerezB.InfraLayer.Security;

namespace Videojuegos_PerezB.Controllers
{
    [Authorize]
    public class JuegosController : Controller
    {
        private static List<Juego> juegos;
        private static List<JuegoPlataforma> juegosYPlataformas;
        VideoJuegosEntities context = new VideoJuegosEntities();

        
        // GET: Juegos
        public ActionResult Index()
        {
            return RedirectToAction("GetJuegos");
        }

        
        public ActionResult GetJuegos(int? page, string juegoBuscar, string tipoBuscar, string filtroActual)
        {
            if (page == null) { page = 1; }
            if (juegoBuscar != null)
            {
                page = 1;
            }
            else
            {
                juegoBuscar = filtroActual;
            }

            ViewBag.CurrentFilter = juegoBuscar;


            if (!String.IsNullOrEmpty(juegoBuscar))
            {
                juegos = context.Juego.OrderByDescending(p => p.IdJuego).Where(b => b.Juego1.ToLower().Contains(juegoBuscar.ToLower().Trim())).ToList();
            }
            else
            {
                juegos = context.Juego.OrderByDescending(p => p.IdJuego).ToList();
            }
            int pageSize = 15;
            int pageNumber = (page ?? 1);
            return View(juegos.ToPagedList(pageNumber, pageSize));
        }


        public ActionResult Create()
        {
            ViewBag.IdTipo = new SelectList(context.Tipo, "IdTipo", "Tipo1");
            return View();
        }

        [HttpPost]
        public ActionResult Create([Bind(Include = "IdJuego,Juego1,IdTipo")] Juego juego)
        {
            if (ModelState.IsValid)
            {
                
                juego.IdJuego = context.Juego.Max(x => x.IdJuego) + 1;
                context.Juego.Add(juego);
                context.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.IdTipo = new SelectList(context.Tipo, "IdTipo", "Tipo1", juego.IdTipo);
            return View(juego);
        }


        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            juegos = context.Juego.OrderByDescending(p => p.IdJuego).ToList();
            Juego juego = juegos.Find(x => x.IdJuego== id);
            if (juego == null)
            {
                return HttpNotFound();
            }
            return View(juego);
        }


        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            Juego juego = context.Juego.Find(id);
            if (juego == null)
            {
                return HttpNotFound();
            }

            ViewBag.IdTipo = new SelectList(context.Tipo, "IdTipo", "Tipo1", juego.IdTipo);
            return View(juego);
        }

        [HttpPost]
        public ActionResult Edit([Bind(Include = "IdJuego,Juego1,IdTipo")] Juego juego)
        {
            if (ModelState.IsValid)
            {
                context.Entry(juego).State = EntityState.Modified;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.IdTipo = new SelectList(context.Tipo, "IdTipo", "Tipo1", juego.IdTipo);
            return View(juego);
        }


        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Juego juego = context.Juego.Find(id);
            if (juego == null)
            {
                return HttpNotFound();
            }
            return View(juego);
        }

        [HttpPost, ActionName("Delete")]

        public ActionResult DeleteConfirmed(int id)
        {
            Juego juego = context.Juego.Find(id);

            juegosYPlataformas = context.JuegoPlataforma.OrderByDescending(p => p.IdJuego).ToList();
            JuegoPlataforma juegoPlataforma = juegosYPlataformas.Find(x => x.IdJuego == id);

            if (juegoPlataforma != null)
            {
                context.JuegoPlataforma.Remove(juegoPlataforma);
            }
            context.Juego.Remove(juego);

            context.SaveChanges();
            return RedirectToAction("GetJuegos");
        }
    }
}