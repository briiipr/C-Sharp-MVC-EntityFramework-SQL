﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Videojuegos_PerezB.InfraLayer.Security;
using Videojuegos_PerezB.Models;

namespace Videojuegos_PerezB.Controllers
{
    [Authorize]
    [AdminFilter]
    public class ClientesController : Controller
    {
        VideoJuegosEntities context = new VideoJuegosEntities();
        // GET: Clientes
        public ActionResult Index()
        {
            return RedirectToAction("GetClientes");
        }

        public ActionResult GetClientes(int? page, string clienteBuscar)
        {
            List<Cliente> listaClientes = new List<Cliente>();
            VideoJuegosEntities contexto = new VideoJuegosEntities();
            if (!String.IsNullOrEmpty(clienteBuscar))
            {
                if (!String.IsNullOrEmpty(clienteBuscar.Trim()))
                {
                    listaClientes = contexto.Cliente.OrderByDescending(p => p.id).Where(b => b.Nombre.ToLower().Contains(clienteBuscar.ToLower())).ToList();
                }
            }
            else
            {
                listaClientes = contexto.Cliente.OrderByDescending(p => p.id).ToList();
            }
            
            int pageSize = 25;
            int pageNumber = (page ?? 1);
            return View(listaClientes.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult GetPuntuaciones(int? page, int id, string nombre)
        {
            List<Puntuacion> listaPuntuaciones = new List<Puntuacion>();
            VideoJuegosEntities contexto = new VideoJuegosEntities();
            if (nombre != null)
            {
                ViewBag.NombreCliente = nombre;
            }
            listaPuntuaciones = contexto.Puntuacion.Where(p => p.Idcliente == id).OrderByDescending(m => m.Id).ToList();
            int pageSize = 25;
            int pageNumber = (page ?? 1);
            return View(listaPuntuaciones.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Cliente cliente)
        {
            if (ModelState.IsValid)
            {
                cliente.id = context.Cliente.Max(x => x.id) + 1;
                cliente.FechaRegistro = DateTime.Now;
                context.Cliente.Add(cliente);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }

        
    }
}