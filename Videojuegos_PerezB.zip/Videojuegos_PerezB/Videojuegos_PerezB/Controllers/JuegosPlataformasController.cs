﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Videojuegos_PerezB.Models;
using PagedList;
using System.Data.Entity;
using Videojuegos_PerezB.InfraLayer.Security;

namespace Videojuegos_PerezB.Controllers
{
    public class JuegosPlataformasController : Controller
    {
        private static List<JuegoPlataforma> juegoPlataformas;
        VideoJuegosEntities context = new VideoJuegosEntities();
        // GET: JuegosPlataformas
        public ActionResult Index()
        {
            return RedirectToAction("GetJuegosPlataformas");
        }

        public ActionResult GetJuegosPlataformas(int? page)
        {
            if (page == null) { page = 1; }

            juegoPlataformas = context.JuegoPlataforma.ToList();

            int pageSize = 15;
            int pageNumber = (page ?? 1);
            return View(juegoPlataformas.ToPagedList(pageNumber, pageSize));
        }
    }
}