﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Videojuegos_PerezB.Models;

namespace Videojuegos_PerezB.Controllers
{
    public class PlataformasController : Controller
    {
        private static List<Plataforma> plataformas;
        VideoJuegosEntities context = new VideoJuegosEntities();
        // GET: Plataformas
        public ActionResult Index()
        {
            return RedirectToAction("GetPlataformas");
        }
        public ActionResult GetPlataformas(int? page, string plataformaBuscar)
        {
            if (page == null) { page = 1; }
            if (!String.IsNullOrEmpty(plataformaBuscar))
            {
                if (!String.IsNullOrEmpty(plataformaBuscar.Trim()))
                {
                    plataformas = context.Plataforma.OrderByDescending(p => p.IdPlataforma).Where(b => b.Plataforma1.ToLower().Contains(plataformaBuscar.ToLower())).ToList();
                }
            }
            else
            {
                plataformas = context.Plataforma.OrderByDescending(p => p.IdPlataforma).ToList();
            }
            int pageSize = 15;
            int pageNumber = (page ?? 1);
            return View(plataformas.ToPagedList(pageNumber, pageSize));
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Plataforma plataforma)
        {
            if (ModelState.IsValid)
            {
                plataforma.IdPlataforma = context.Plataforma.Max(x => x.IdPlataforma) + 1;
                context.Plataforma.Add(plataforma);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View();
            }
        }
    }
}