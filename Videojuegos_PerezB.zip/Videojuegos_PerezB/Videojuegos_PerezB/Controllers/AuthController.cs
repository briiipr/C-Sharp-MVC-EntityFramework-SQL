﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using System.Web.Security;
using Videojuegos_PerezB.Models;
using Videojuegos_PerezB.InfraLayer.Security;
using Videojuegos_PerezB.DAL;

namespace Videojuegos_PerezB.Controllers
{
    public class AuthController : Controller
    {
        // GET: Auth
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public ActionResult Login()
        {
            Usuario usuarioComprueba = null;
            usuarioComprueba = Session["PERSONA"] as Usuario;
            if (usuarioComprueba != null)
                return RedirectToAction("Index", "Home");
            else
                return View();
        }

        [HttpPost]
        public ActionResult Login(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                Usuario authUser = null;
                using (VideoJuegosEntities2 contexto = new VideoJuegosEntities2())
                {
                    string hashedPass = ShaUtils.GenerateSHA256String(usuario.Password);
                    authUser = contexto.Usuario.Include(usu => usu.UsuarioGrupo.Select(y => y.Grupo)).
                        FirstOrDefault(u => u.Login == usuario.Login && u.Password == hashedPass);
                }

                if (authUser != null)
                {
                    FormsAuthentication.SetAuthCookie(authUser.Login, false);
                    Session["PERSONA"] = authUser;

                    if (authUser.UsuarioGrupo.Select(b => b.Grupo.Nombre).FirstOrDefault() == "admin")
                        return RedirectToAction("Index", "Admin");
                    else
                        return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError("Error de credenciales", "Usuario o contraseña incorrectos");
                    return RedirectToAction("Login");
                }
            }
            else
                return View();
        }
    }
}